### This is an R script tangled from 'json-mapping.pdf.asis'
