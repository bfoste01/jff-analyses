library("testthat")
library("pacman")
options(repos="http://cran.rstudio.com/")


test_check("pacman")