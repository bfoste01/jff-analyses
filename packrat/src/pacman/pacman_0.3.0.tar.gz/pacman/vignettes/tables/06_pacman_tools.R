| pacman Function | Base Equivalent | Description |
|----------------------|----------------------|----------------|
| `p_detectOS`   | `Sys.info` | Detect Operating System |
| `p_extract`   | NONE | Extract Packages from String |
| `p_opendir`  | `system`/`shell`  | Open a Directory |